/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repositorio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author Oscar
 */
public class Computador {
    private String marca;
    private String modelo;
    private String procesador;
    private String pulgada;
    private String TaRam;
    private String tVideo;

    public Computador(String marca, String modelo, String procesador, String pulgada, String TaRam, String tVideo) {
        this.marca = "marca";
        this.modelo = "modelo";
        this.procesador = "procesador";
        this.pulgada = "pulgada";
        this.TaRam = "tarjeta video";
        this.tVideo = null;
    }
    
    public Computador(){
        
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }

    public String getPulgada() {
        return pulgada;
    }

    public void setPulgada(String pulgada) {
        this.pulgada = pulgada;
    }

    public String getTaRam() {
        return TaRam;
    }

    public void setTaRam(String TaRam) {
        this.TaRam = TaRam;
    }

    public String gettVideo() {
        return tVideo;
    }

    public void settVideo(String tVideo) {
        this.tVideo = tVideo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + Objects.hashCode(this.marca);
        hash = 43 * hash + Objects.hashCode(this.modelo);
        hash = 43 * hash + Objects.hashCode(this.procesador);
        hash = 43 * hash + Objects.hashCode(this.pulgada);
        hash = 43 * hash + Objects.hashCode(this.TaRam);
        hash = 43 * hash + Objects.hashCode(this.tVideo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Computador other = (Computador) obj;
        return true;
    }
    

    @Override
    public String toString() {
        return "Computador{" + "marca=" + marca + ", modelo=" + modelo + ", procesador=" + procesador + ", pulgada=" + pulgada + ", TaRam=" + TaRam + ", tVideo=" + tVideo + '}';
    }
    
    public void agregarTipoList(){
        List lista1 = new LinkedList();
		lista1.add(marca);
                lista1.add(procesador);
		lista1.add(modelo);
		lista1.add(pulgada);
                lista1.add(TaRam);
		Iterator iterador = lista1.iterator();
 
		while (iterador.hasNext()) {
			String elemento = (String) iterador.next();
			System.out.print(elemento + " ");
		}
		System.out.println(" ");
    }
    public void agregarTipoSet(){
        
	// Definir un HashSet
        HashSet mandado = new HashSet();
        mandado.add(TaRam);
        mandado.add(marca);
        mandado.add(modelo);
        mandado.add(procesador);
        mandado.add(pulgada);

        Iterator iterador = mandado.iterator();
 
		while (iterador.hasNext()) {
			String manda = (String) iterador.next();
			System.out.print(manda + " ");
		}
		System.out.println(" ");
    }
    public void agregarTipoTree(){
        
        TreeSet ts = new TreeSet();
		ts.add("DELL INSPIRON");
		ts.add("SONY VAIO");
		ts.add("LENOVO GTI");
		System.out.println(ts);
	}

        
    
    public void agregarTipoHashMap(){

		HashMap hm = new HashMap();
 
		hm.put("HP", "MODELO 1");
		hm.put("SONY", "MODELO 2");
		hm.put("TOSHIBA", "MODELO 3");
		hm.put("DELL", "MODELO 4");
		hm.put("LENOVO", "MODELO 5");
 
		// Definir Iterator para extraer o imprimir valores 
		for( Iterator it = hm.keySet().iterator(); it.hasNext();) { 
			String s = (String)it.next();
			String s1 = (String)hm.get(s);
			System.out.println("LA MARCA ES: "+s + " - " + "Y LA VERSION ES: "+s1);
    }
    }
    public static void main(String[] args) {
     
                System.out.println("ITERATOR LIST");
                Computador cp = new Computador();
                cp.agregarTipoList();
                System.out.println("");
                System.out.println("ITERATOR SET");
                cp.agregarTipoSet();
                System.out.println("");
                System.out.println("ITERATOR HASHMAP");
                cp.agregarTipoHashMap();
                System.out.println("");
                System.out.println("ITERATOR TREESET");
                cp.agregarTipoTree();
                


	}
}
     
    



    
    
    

